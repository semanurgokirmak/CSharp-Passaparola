﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace passaparola
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int soruno= 0,dogru=0, yanlıs = 0;

        private void button26_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)      
            
        {
            if (e.KeyCode == Keys.Enter)                                

            {
                switch (soruno)
                {
                    case 1:
                        if(textBox1.Text == "akdeniz")
                        {
                            button1 .BackColor = Color .Green ;
                            dogru++;
                            label3 .Text =dogru .ToString();
                        }
                        else
                        {
                            button1 .BackColor = Color .Red ;
                            yanlıs ++;
                            label4 .Text =yanlıs .ToString();
                        }
                        break;
                        case 2:
                        if( textBox1.Text == "balık")
                        {
                            button2 .BackColor = Color .Green ;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button2.BackColor = Color .Red ;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                        case 3:
                        if( textBox1.Text == "cuma")
                        {
                            button3.BackColor = Color .Green ;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button3 .BackColor = Color .Red ;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                        case 4: 
                        if ( textBox1.Text == "diyarbakır")
                        {
                            button4 .BackColor = Color .Green ;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button4 .BackColor= Color .Red ;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break ;
                        case 5: 
                        if( textBox1.Text == "eski")
                        {
                            button5 .BackColor = Color .Green ;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button5 .BackColor= Color .Red ;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                        case 6:
                        if ( textBox1.Text == "ferman")
                        {
                            button6 .BackColor = Color .Green ;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button6 .BackColor= Color .Red ;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                        case 7: 
                        if ( textBox1.Text == "galip")
                        {
                            button7 .BackColor = Color .Green ;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button7.BackColor= Color .Red ;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 8:
                        if (textBox1.Text == "hava")
                        {
                            button8.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button8.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 9:
                        if (textBox1.Text == "ısırgan")
                        {
                            button9.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button9.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 10:
                        if (textBox1.Text == "irade")
                        {
                            button10.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button10.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 11:
                        if (textBox1.Text == "jinekolog")
                        {
                            button11.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button11.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 12:
                        if (textBox1.Text == "kasiyer")
                        {
                            button12.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button12.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 13:
                        if (textBox1.Text == "lale")
                        {
                            button13.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button13.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 14:
                        if (textBox1.Text == "müracaat")
                        {
                            button14.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button14.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 15:
                        if (textBox1.Text == "ney")
                        {
                            button15.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button15.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 16:
                        if (textBox1.Text == "ozan")
                        {
                            button16.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        else
                        {
                            button16.BackColor = Color.Red;
                        }
                        break;
                    case 17:
                        if (textBox1.Text == "pekin")
                        {
                            button17.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button17.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 18:
                        if (textBox1.Text == "ramazan")
                        {
                            button18.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button18.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 19:
                        if (textBox1.Text == "snake")
                        {
                            button19.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button19.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 20:
                        if (textBox1.Text == "taraftar")
                        {
                            button20.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button20.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 21:
                        if (textBox1.Text == "uzay")
                        {
                            button21.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button21.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 22:
                        if (textBox1.Text == "vatikan")
                        {
                            button22.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        
                        else
                        {
                            button22.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 23:
                        if (textBox1.Text == "yankı")
                        {
                            button23.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                        }
                        else
                        {
                            button23.BackColor = Color.Red;
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        break;
                    case 24:
                        if (textBox1.Text == "zebani")
                        {
                            button24.BackColor = Color.Green;
                            dogru++;
                            label3.Text = dogru.ToString();
                            yanlıs++;
                            label4.Text = yanlıs.ToString();
                        }
                        else
                        {
                            button24.BackColor = Color.Red;
                        }
                        break;



                } 
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.Text = "SONRAKİ";
            soruno++;
            this.Text = soruno .ToString();             
            textBox1.Text = string.Empty;              
                                                        
            textBox1.Focus();                       


            if (soruno ==1)
            {
                richTextBox1.Text = "Ülkemizin Güney Kıyısındaki Coğrafi Bölge";
                button1 .BackColor = Color .Orange ;
                button25.Text = button1.Text;

            }

            if (soruno == 2)
            {
                richTextBox1.Text = "Tamamı Denizde Yaşayan ve Bazı Türleri Yenebilen Hayvan";
                button2.BackColor = Color.Orange;
                button25.Text = button2.Text;

            }

            if (soruno == 3)
            {
                richTextBox1.Text = "Müslümanların Kutsal Günü";
                button3.BackColor = Color.Orange;
                button25.Text = button3.Text;

            }
            if (soruno == 4)
            {
                richTextBox1.Text = "Ülkemizin Karpuzu İle Meşhur İli";
                button4.BackColor = Color.Orange;
                button25.Text = button4.Text;

            }
            if (soruno == 5)
            {
                richTextBox1.Text = "Yeninin Zıt Anlamlısı";
                button5.BackColor = Color.Orange;
                button25.Text = button5.Text;

            }
            if (soruno == 6)
            {
                richTextBox1.Text = "Padişahların Emirlerinin Yazılı Hali";
                button6.BackColor = Color.Orange;
                button25.Text = button6.Text;

            }
            if (soruno == 7)
            {
                richTextBox1.Text = "Bir Oyunda Kazanan Kişiye Verilen Ad";
                button7.BackColor = Color.Orange;
                button25.Text = button7.Text;

            }
            if (soruno == 8)
            {
                richTextBox1.Text = "Doğada Bulunan 4 Elementten Biri";
                button8.BackColor = Color.Orange;
                button25.Text = button8.Text;

            }
            if (soruno == 9)
            {
                richTextBox1.Text = "Dokunduğumuzda Şiddetli Kaşıntıya Sebep Olan Ot";
                button9.BackColor = Color.Orange;
                button25.Text = button9.Text;

            }
            if (soruno == 10)
            {
                richTextBox1.Text = "İnsanın Kendisine Hakim Olma Gücü";
                button10.BackColor = Color.Orange;
                button25.Text = button10.Text;

            }
            if (soruno == 11)
            {
                richTextBox1.Text = "Kadın Hastalıkları Doktorunun Diğer Unvanı";
                button11.BackColor = Color.Orange;
                button25.Text = button11.Text;

            }
            if (soruno == 12)
            {
                richTextBox1.Text = "Market ve Mağaza Alışverişlerimizde Ödemeyi Yaptığımız Kişi";
                button12.BackColor = Color.Orange;
                button25.Text = button12.Text;

                

            }
            if (soruno == 13)
            {
                richTextBox1.Text = "Her Yıl Baharda Düzenlenen Çiçek Festivalinin Adı";
                button13.BackColor = Color.Orange;
                button25.Text = button13.Text;

            }
            if (soruno == 14)
            {
                richTextBox1.Text = "Başvurunun Eş Anlamlısı";
                button14.BackColor = Color.Orange;
                button25.Text = button14.Text;

            }
            if (soruno == 15)
            {
                richTextBox1.Text = "Üflemeli Bir Müzik Aleti";
                button15.BackColor = Color. Orange;
                button25.Text = button15.Text;

            }
            if (soruno == 16)
            {
                richTextBox1.Text = "Halk Şairlerine Verien Genel Ad";
                button16.BackColor = Color.Orange;
                button25.Text = button16.Text;

            }
            if (soruno == 17)
            {
                richTextBox1.Text = "Çin'in Başkenti";
                button17.BackColor = Color.Orange;
                button25.Text = button17.Text;

            }
            if (soruno == 18)
            {
                richTextBox1.Text = "11 Ayın Sultanı";
                button18.BackColor = Color.Orange;
                button25.Text = button18.Text;

            }
            if (soruno == 19)
            {
                richTextBox1.Text = "Yılanın İngilizcesi";
                button19.BackColor = Color.Orange;
                button25.Text = button19.Text;

            }
            if (soruno == 20)
            {
                richTextBox1.Text = "Bir Takımı Tutan Topluluk";
                button20.BackColor = Color.Orange;
                button25.Text = button20.Text;

            }
            if (soruno == 21)
            {
                richTextBox1.Text = "Tüm Gezegenleri İçinde Barındıran Boşluk";
                button21.BackColor = Color.Orange;
                button25.Text = button21.Text;

            }
            if (soruno == 22)
            {
                richTextBox1.Text = "Vatikan'ın Başkenti";
                button22.BackColor = Color.Orange;
                button25.Text = button22.Text;

            }
            if (soruno == 23)
            {
                richTextBox1.Text = "Sesin Bir Yüzeye Çarpıp Tekrar Yansıması";
                button23.BackColor = Color.Orange;
                button25.Text = button23.Text;

            }
            if (soruno == 24)
            {
                richTextBox1.Text = "Cehennem Meleğinin Diğer Adı";
                button24.BackColor = Color.Orange;
                button25.Text = button24.Text;

            }
        }
    }
}
